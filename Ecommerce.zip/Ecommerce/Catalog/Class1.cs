﻿namespace Catalog;

public class Class1
{

}

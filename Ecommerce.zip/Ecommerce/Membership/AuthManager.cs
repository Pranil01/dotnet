namespace MemberShip;

public static class AuthManager{
     public static bool validate (string email,string pwd){

        bool status = false;

        if(email=="SumedhShingade@gmail.com"&&pwd=="iet@100"){
            status = true;
        }
            return status;

     }

     public static bool register(string email,string pwd){
        bool status=false;
       return status;

     } 

}
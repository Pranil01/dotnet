﻿namespace Membership;

public class Class1
{

}

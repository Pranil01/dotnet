// import package
namespace CRM;
public class Customer{

    public string FirstName{
        get;set;
    }
    public string LastName{get;set;}

    public string contact{
        get;set;
    }

}
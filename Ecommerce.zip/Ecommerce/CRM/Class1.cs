﻿namespace CRM;

public class Class1
{

}

﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using Catalog;
using CRM;
using MemberShip;
using OrderProcessing;
using ShoppingCart;

Product p = new Product{
                  Id =  100,
                  Title="Gerbera",
                         Description="Wedding Flower",
                         UnitPrice=10,
                         Quantity=5600
};

p.Title="Jasmin";
Console.WriteLine("Title:"+p.Title+" "+ "Description:"+ p.Description);
namespace OrderProcessing;

public class Order{

public int ID{get;set;}
public DateTime OrderDate{get;set;}
public double subtotal{get;set;}

public string status{get;set;}


}
﻿namespace OrderProcessing;

public class Class1
{

}
